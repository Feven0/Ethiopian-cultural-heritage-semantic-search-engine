
  
  package controller;


import java.io.IOException;
import java.net.URL;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.VBox;
import model.Destination;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.util.FileManager;
  
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import model.ImageM;
  
import javafx.scene.image.Image;
  
public class ImageController implements Initializable {        


    @FXML
    private Text author;

    @FXML
    private VBox imagebox;

    @FXML
    private ImageView imageviewBox;
    
    
    
   
 
   
    public void setData(ImageM img ){
        
//        imageviewBox.setImage(new Image(img.getSrc()));
        author.setText("By: "+img.getAuthor());
        Image image = new Image(img.getSrc());
        imagebox.setMinHeight(image.getHeight()+30.0);
        imageviewBox.setImage(image);
//        System.out.print(img.getAuthor());
        
  
    }
//#7aaaea
    
  
    @Override      
    public void initialize(URL url, ResourceBundle rb) {

            
    }       
    

}


