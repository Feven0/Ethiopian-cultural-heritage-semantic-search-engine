
  
  package controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.net.URL;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.VBox;
import model.Destination;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.util.FileManager;
import java.util.ResourceBundle;
import javafx.scene.control.ScrollPane;
  
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.Map;
import javafx.scene.text.TextFlow;
import model.ImageM;
public class ResultController implements Initializable {        

    @FXML
    private HBox allimagebox;

    @FXML
    private Text otherfield;

    @FXML
    private Text assecionfield;

    @FXML
    private Button closeBtn;

    @FXML
    private Text datefield;

    @FXML
    private Text descfield;

    @FXML
    private Text dimensionfield;

    @FXML
    private Text latfield;

    @FXML
    private Text longfield;

    @FXML
    private Text mediumfield;

    @FXML
    private Text namefield;

    @FXML
    private Text narratorfield;

    @FXML
    private Text regionfield;

    @FXML
    private TextFlow totalfield;
    
    @FXML
    private Text photofield;
    
    @FXML
    private ScrollPane videoscroll;
    
    @FXML
    private Text coordinatefield;
    
        @FXML
    private ScrollPane imagescroll;
    
    private String subject;
    
    
        @FXML
    private HBox allvideobox;
        
            @FXML
    private Text videofield;
            
    public ResultController() {
        // Default constructor
    }
    
    public ResultController(String subject) {
        this.subject = subject;
    }

    @FXML
    void closeBtn(ActionEvent event) {

    
        System.exit(0);
    }
    
    public void setData(){
    
        	    FileManager.get().addLocatorClassLoader(ResultController.class.getClassLoader());
	    Model model=FileManager.get().loadModel("C:/Users/Dell/Documents/ss.rdf");
//        	    String subject = "http://www.semanticweb.org/feven/ontologies/2023/4/untitled-ontology-5#Aksum";

	    String queryString = "PREFIX untitled-ontology-5: <http://www.semanticweb.org/feven/ontologies/2023/4/untitled-ontology-5#>\r\n"
	        + "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\r\n"
	        + "\r\n"
	        + "SELECT DISTINCT ?name ?desc ?totalDesc ?region (SUM(?score) AS ?relevanceScore) (COALESCE(?image, \"\") AS ?imageValue) \r\n"
	        +"(COALESCE(?artist, \"\") AS ?artistValue) (COALESCE(?coordinates, \"\") AS ?coordinatesValue)  (COALESCE(?video, \"\") AS ?videoValue)  (COALESCE(?accessionno, \"\") AS ?accessionnoValue) (COALESCE(?date, \"\") AS ?dateValue) (COALESCE(?narrator, \"\") AS ?narratorValue) (COALESCE(?medium, \"\") AS ?mediumValue) (COALESCE(?dimensions, \"\") AS ?dimensionsValue)\r\n"
	        + "WHERE { \r\n"
	        + "  <" + subject + "> untitled-ontology-5:Name ?name;\r\n"
	        + "   untitled-ontology-5:Description ?desc;\r\n"
	        + "   untitled-ontology-5:TotalDescription ?totalDesc;\r\n"
	        + " untitled-ontology-5:Region ?region .\r\n"
	        + "  OPTIONAL { <" + subject + "> untitled-ontology-5:ImageAuthor ?image . }\r\n"
	        + "  OPTIONAL { <" + subject + "> untitled-ontology-5:Artist ?artist . }\r\n"
	        + "  OPTIONAL { <" + subject + "> untitled-ontology-5:AccessionNumber ?accessionno . }\r\n"
	        + "  OPTIONAL { <" + subject + "> untitled-ontology-5:Coordinates ?coordinates . }\r\n"
	        + "  OPTIONAL { <" + subject + "> untitled-ontology-5:Date ?date . }\r\n"
	        + "  OPTIONAL { <" + subject + "> untitled-ontology-5:Medium ?medium . }\r\n"
	        + "  OPTIONAL { <" + subject + "> untitled-ontology-5:Narrator ?narrator . }\r\n"
	        + "  OPTIONAL { <" + subject + "> untitled-ontology-5:Dimensions ?dimensions . }\r\n"
	        + "  OPTIONAL { <" + subject + "> untitled-ontology-5:Video ?video . }\r\n"
	        + "  \r\n"
	        + "} \r\n"
	        + "GROUP BY ?name ?desc ?totalDesc ?region ?image ?artist ?accessionno ?coordinates ?date ?medium ?narrator ?dimensions ?video\r\n";
            
            	      System.out.println("pass ");
//	    String queryString="PREFIX untitled-ontology-5: <http://www.semanticweb.org/feven/ontologies/2023/4/untitled-ontology-5#>\r\n"
//	        + "\r\n"
//	        + "SELECT  ?description WHERE {\r\n"
//	        + "  <http://www.semanticweb.org/feven/ontologies/2023/4/untitled-ontology-5#Aksum> untitled-ontology-5:Description ?description .\r\n"
//	        + "}";
	      Query query = QueryFactory.create(queryString);
	      try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
	          ResultSet results = qexec.execSelect();
	          System.out.println(results.getRowNumber());
	          if (results != null) {
	              while (results.hasNext()) {
	                  QuerySolution soln = results.nextSolution();
	  	            
                          String imageAuthor="",artistValue="",coordinatesValue="",dateValue="",accessionnoValue="",narratorValue="",mediumValue="",dimensionsValue="",videoValue="";
	    	          
	                  String region = soln.getLiteral("region").getString();
	  	            String name = soln.getLiteral("name").getString();
	  	            String desc = soln.getLiteral("desc").getString();
	  	            String totalDesc = soln.getLiteral("totalDesc").getString();
	  	            
	  	             imageAuthor = soln.getLiteral("imageValue").getString();
	  	             artistValue = soln.getLiteral("artistValue").getString();
	  	             coordinatesValue = soln.getLiteral("coordinatesValue").getString();
	  	             dateValue = soln.getLiteral("dateValue").getString();
	  	             accessionnoValue = soln.getLiteral("accessionnoValue").getString();
	  	             narratorValue = soln.getLiteral("narratorValue").getString();
	  	             mediumValue = soln.getLiteral("mediumValue").getString();
	  	             dimensionsValue = soln.getLiteral("dimensionsValue").getString();
                             
	  	             videoValue = soln.getLiteral("videoValue").getString();
	  	            
                             
	  	                   String newName = name.replace("\\", "");
                                  newName = newName.replace("\\", "");
                                  newName = newName.replaceAll("'", "");
                                  newName = newName.replaceAll("'", "");
//                            String  x=name.replace("'", "");
		  	           namefield.setText(newName);
                                    descfield.setText(desc);
                                       
    descfield.setStyle("-fx-font-size: 18px;");

                                    regionfield.setText(region);
                                    
                                    
                                    ObjectMapper objectMapper = new ObjectMapper();
                                        
if (totalDesc.toLowerCase().startsWith("{")) {
        Text text1 = new  Text(""),text2 = new  Text(""),text3 = new  Text(""),text4=new  Text(""),text5 = new  Text(""),text6 = new  Text(""),text7 = new  Text(""),text8 =new  Text("");
    try {
JsonNode jsonNode = objectMapper.readTree(totalDesc);

    if (jsonNode.has("Brief synthesis")) {
     String    bs = jsonNode.get("Brief synthesis").asText();
      if(!bs.isEmpty()){
            
            text1.setText("Brief synthesis" + "\n");
            text1.setStyle("-fx-font-weight: bold; -fx-font-size: 15px; -fx-text-fill: grey;");
            
            text2.setText( bs + "\n\n");
            
               text2.setStyle("-fx-font-size: 15px;  -fx-text-fill: grey;");
            
       
      }
    }
    
    if (jsonNode.has("Authenticity")) {
        String aa = jsonNode.get("Authenticity").asText();
         if(!aa.isEmpty()){
                     text3.setText("Authenticity" + "\n");
            text3.setStyle("-fx-font-weight: bold; -fx-font-size: 15px;");
            
            text4.setText( aa + "\n\n");
               text4.setStyle("-fx-font-size: 15px;");
      }
    }
    
    if (jsonNode.has("Integrity")) {
        String ii = jsonNode.get("Integrity").asText();
            if(!ii.isEmpty()){
                              text5.setText("Integrity" + "\n");
    text5.setStyle("-fx-font-weight: bold; -fx-font-size: 15px;");
            
            text6.setText( ii + "\n\n");
               text6.setStyle("-fx-font-size: 15px;");
      }
    }
    
    if (jsonNode.has("Protection and management requirements")) {
       String  pm = jsonNode.get("Protection and management requirements").asText();
                 if(!pm.isEmpty()){
                                     text7.setText("Protection and management requirements" + "\n");
            text7.setStyle("-fx-font-weight: bold; -fx-font-size: 15px;");
            
            text8.setText( pm + "\n\n");
            
               text8.setStyle("-fx-font-size: 15px;");
      }
    }
    
 // Assume you have a JavaFX TextField named totalfield
// Assume you have a JavaFX TextField named totalfield

if (text2 != null && !text2.getText().isEmpty() && !text2.getText().toLowerCase().contains("null")) {
    totalfield.getChildren().add(text1);
    totalfield.getChildren().add(text2);
}
if (text4 != null && !text4.getText().isEmpty() && !text4.getText().toLowerCase().contains("null")) {
   totalfield.getChildren().add(text3);
   totalfield.getChildren().add(text4);
}
if (text6 != null && !text6.getText().isEmpty() && !text6.getText().toLowerCase().contains("null")) {
    totalfield.getChildren().add(text5);
    totalfield.getChildren().add(text6);
}
if (text8 != null && !text8.getText().isEmpty() && !text8.getText().toLowerCase().contains("null")) {
     totalfield.getChildren().add(text7);
     totalfield.getChildren().add(text8);
}
    
} catch (JsonProcessingException e) {
}
} else {
    System.out.println("String does not start with {");
    Text textt=new  Text(totalDesc);
    
     textt.setStyle("-fx-font-size: 15px;");
    totalfield.getChildren().add(textt);
}
 
        if (otherfield != null) {
    otherfield.setText(" ");
    otherfield.setStyle("-fx-font-size: 16px;");
    if(!artistValue.isEmpty())
{
     otherfield.setText(otherfield.getText()+  "Artist: "+ artistValue+"      ");
}

if(!accessionnoValue.isEmpty())
{
     otherfield.setText(otherfield.getText()+  "Accession Number: "+ accessionnoValue+"      ");
}

if(!narratorValue.isEmpty())
{
     otherfield.setText(otherfield.getText()+  "Narrator: "+ narratorValue+"      ");
}

if(!mediumValue.isEmpty())
{
     otherfield.setText(otherfield.getText()+  "Medium: "+ mediumValue+"      ");
}

if(!dimensionsValue.isEmpty())
{
     otherfield.setText(otherfield.getText()+  "Dimenstion: "+ dimensionsValue+"      ");
}
}

        
        
        
if (imageAuthor.toLowerCase().startsWith("[")) {
    System.out.print("Ddddddddddddds");
        Gson gson = new Gson();
List<List<Map<String, String>>> imageList = gson.fromJson(imageAuthor, List.class);
        
            List<ImageM> images = new ArrayList<>();
       for (List<Map<String, String>> imageDict : imageList) {
    String src = "";
    String author = "";
    for (Map<String, String> dict : imageDict) {
        for (Map.Entry<String, String> entry : dict.entrySet()) {
            if (entry.getKey().equals("src")) {
                src = entry.getValue();
            } else if (entry.getKey().equals("author")) {
                author = entry.getValue();
            }
        }
    }
    ImageM image = new ImageM();
    image.setAuthor(author);
    image.setSrc(src);
    images.add(image);
         

}
       
//        System.out.println(images.size());

photofield.setVisible(true);
                       try{
                            
                     
                     
                  for(int i=0;i<images.size();i++){
                   
                       FXMLLoader fxmlLoader=new FXMLLoader();
                      fxmlLoader.setLocation(getClass().getResource("/UI/imagecard.fxml"));
                     VBox newimagebox=fxmlLoader.load();
                             
                     ImageController resultController=fxmlLoader.getController();
                     resultController.setData(images.get(i));  
                     
                    
                     allimagebox.getChildren().add(newimagebox);
                     allimagebox.setMinHeight(260.0);
                          imagescroll.setMinHeight(260.0);
//                      System.out.println(allimagebox.getPrefHeight());
//                     scrollPane.setClip(newResultBox);
                    
                     
                  }}catch(IOException e){
                      e.printStackTrace();
                  }
}else{
        System.out.print("nnnnnoooooooooooooooopics");

}   
       
System.out.print(videoValue);

//if (videoValue.toLowerCase().startsWith("[")) {
//    System.out.print("Dddddddddddddsaaaaa");
//        Gson gson = new Gson();
//List<List<Map<String, String>>> videoList = gson.fromJson(videoValue, List.class);
//        
//            List<ImageM> videos = new ArrayList<>();
//       for (List<Map<String, String>> imageDict : videoList) {
//    String src = "";
//    String author = "";
//    for (Map<String, String> dict : imageDict) {
//        for (Map.Entry<String, String> entry : dict.entrySet()) {
//            if (entry.getKey().equals("vidSrc")) {
//                src = entry.getValue();
//                 System.out.print(src);
//            } else if (entry.getKey().equals("copyright")) {
//                author = entry.getValue();
//            }
//        }
//    }
//    ImageM video = new ImageM();
//    video.setAuthor(author);
//    video.setSrc(src);
//    videos.add(video);
//         
//
//} System.out.print("hupp"+videos.size());
//       
////        System.out.println(images.size());
//
//videofield.setVisible(true);
//                       try{
//                            
//                     
//                     
//                  for(int i=0;i<videos.size();i++){
//                   
//                       FXMLLoader fxmlLoader=new FXMLLoader();
//                      fxmlLoader.setLocation(getClass().getResource("/UI/videocard.fxml"));
//                     
//                             
//                     VideoController resultController=fxmlLoader.getController();
//                     resultController.setData(videos.get(i));  
//                     VBox newvideobox=fxmlLoader.load();
//                    
//                     allvideobox.getChildren().add(newvideobox);
//                     allvideobox.setMinHeight(260.0);
//                       videoscroll.setMinHeight(260.0);
////                      System.out.println(allimagebox.getPrefHeight());
////                     scrollPane.setClip(newResultBox);
//                    
//                     
//                  }}catch(IOException e){
//                      e.printStackTrace();
//                  }
//}else{
//        System.out.print("nnnnnoooooooooooooooovids");
//
//}   
       

if (coordinatesValue.toLowerCase().startsWith("[")) {
        
    // Create a new Gson instance
    Gson gson = new Gson();
    // Deserialize the JSON string to a JsonArray
    JsonArray jsonArray = gson.fromJson(coordinatesValue, JsonArray.class);
    // Get the inner array from the JsonArray
    JsonArray innerArray = jsonArray.get(0).getAsJsonArray();
    // Extract the latitude and longitude values from the inner array
    double lat = innerArray.get(0).getAsJsonObject().get("Latitude").getAsDouble();
    double lon = innerArray.get(1).getAsJsonObject().get("Longitude").getAsDouble();
    // Display the latitude and longitude values in the TextFields
    coordinatefield.setVisible(true);
    latfield.setText("Latitude: "+Double.toString(lat));
    longfield.setText("Longitude: "+Double.toString(lon));
}else{ System.out.print("nnnnnooooooooooooooooCoordinates");}


//                                    totalfield.setText(totalDesc);
//                                    artistfield.setText(imageAuthor);
//                                    otherfield.setText(artistValue);
//                                    artistfield.setText(coordinatesValue);
                                    datefield.setText(dateValue);
//                                    assecionfield.setText(accessionnoValue);
//                                    narratorfield.setText(narratorValue);
//                                    mediumfield.setText(mediumValue);
//                                    dimensionfield.setText(dimensionsValue);
                                    
                                 
                                    
////	  	            System.out.println("Subject: " + sub);
////	  	            System.out.println("name: " + name);
//	  	            System.out.println("desc: " + desc);
//	  	            System.out.println("totalDesc: " + totalDesc);	  	
//	  	            System.out.println("imageValue: " + imageAuthor); 	  	
//	  	            System.out.println("region: " + artistValue);	  	
//	  	            System.out.println("region: " + coordinatesValue);	  	
//	  	            System.out.println("region: " + accessionnoValue);	  	
//	  	            System.out.println("region: " + dateValue);	  	
//	  	            System.out.println("region: " + narratorValue);	  	
//	  	            System.out.println("region: " + mediumValue);	  	
//	  	            System.out.println("region: " + dimensionsValue);
	  	            
		              }
	          }
	      	  }
	
	



}
    
       @Override      
    public void initialize(URL url, ResourceBundle rb) {
        System.out.println(subject+"dd");

        setData();
        
    }  

}


