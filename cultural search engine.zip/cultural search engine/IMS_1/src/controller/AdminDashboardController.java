
  
  package controller;


import java.io.IOException;
import java.net.URL;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.VBox;
import model.Destination;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.util.FileManager;
import java.util.ResourceBundle;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ScrollPane;
import javafx.scene.text.Text;
  
public class AdminDashboardController implements Initializable {        


    @FXML
    private Button closeBtn;

    @FXML
    private AnchorPane dashboardAnchor;

    @FXML
    private Button minimizeBtn;

    @FXML
    private AnchorPane profileAnchor;

    @FXML
    private AnchorPane profileAnchor1;
    
    @FXML
    private Button searchBtn;    
    
    @FXML
    private TextField searchTerm;
    
     @FXML
    private ScrollPane scrollPane;
    

    @FXML
    void closeBtn(ActionEvent event) {
        System.exit(0);
    }
    
    @FXML
    private ComboBox<String> comboBox;
                // create the root TreeItem
    
    @FXML
    void minimizeBtn(ActionEvent event) {

        Stage oldstage = (Stage) minimizeBtn.getScene().getWindow();
        oldstage.setIconified(true);
    }
    
    
    @FXML
    private VBox resultBox;
    private List<Destination> results;
    
//    private List<Destination> data(String name,String desc, String totalDesc, String region){
////        List<Destination> ls=new ArrayList<>();
////        
////        
////        Destination destination = new Destination(name, desc, totalDesc, region);
////      
////        ls.add(destination);
////      return ls;  
//    }
    
   
    
    
    @FXML
    void searchBtn(ActionEvent event) {
        String selectedCombo = comboBox.getValue();   
        
        String inputText = searchTerm.getText();
        
        if(!selectedCombo.isEmpty() && !inputText.isEmpty()) {
            resultBox.getChildren().clear();
            try {      
                
                 selectedCombo = selectedCombo.replace(" ", "");
                 System.out.println(selectedCombo);
                 
                 System.out.println(inputText);
                 
                    
                sparqlTest(inputText, selectedCombo);
                
            } catch (IOException ex) {
                Logger.getLogger(AdminDashboardController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            if(selectedCombo.isEmpty()) {
                 comboBox.setStyle("-fx-border-color: red;");
            }
            if(inputText.isEmpty()) {
                searchTerm.setStyle("-fx-border-color: red;");
            }
    
                Alert alert = new Alert(AlertType.ERROR);
//                alert.setTitle("Error");
                alert.setHeaderText("Please enter/select values for both arguments.");
//                alert.setContentText("Please enter/select values for both arguments.");
                alert.showAndWait();
                
                comboBox.setStyle("");
                searchTerm.setStyle("");
        }
        
    }
    
    void sparqlTest(String searchTerm,String classType) throws IOException {
		
	    FileManager.get().addLocatorClassLoader(AdminDashboardController.class.getClassLoader());
	    Model model=FileManager.get().loadModel("C:/Users/Dell/Documents/ss.rdf");
	
//	     classType = "Tangible";
//	     searchTerm = "Aksum";
	    
	    //first..normal
	    String queryString = "PREFIX untitled-ontology-5: <http://www.semanticweb.org/feven/ontologies/2023/4/untitled-ontology-5#>\r\n"
	    + "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\r\n"
	    + "\r\n"
	    + "SELECT DISTINCT ?subject ?name ?desc ?totalDesc ?region (SUM(?score) AS ?relevanceScore) WHERE {\r\n"
	    + "  ?subject a/rdfs:subClassOf* untitled-ontology-5:" + classType + " .\r\n"
	    + "  ?subject untitled-ontology-5:Name ?name .\r\n"
	    + "  ?subject untitled-ontology-5:Description ?desc .\r\n"
	    + "  ?subject untitled-ontology-5:TotalDescription ?totalDesc .\r\n"
	    + "  ?subject untitled-ontology-5:Region ?region .\r\n"
	    
	    + "  \r\n"
	    + "  # Calculate relevance score based on search term matches in properties\r\n"
	    + "  BIND(IF(regex(?name, \"" + searchTerm + "\", \"i\"), 4, 0) +\r\n"
	    + "       IF(regex(?desc, \"" + searchTerm + "\", \"i\"), 3, 0) +\r\n"
	    + "       IF(regex(?totalDesc, \"" + searchTerm + "\", \"i\"), 2, 0) +\r\n"
	    + "       IF(regex(?region, \"" + searchTerm + "\", \"i\"), 1, 0)\r\n"
	    + "       AS ?score)\r\n"
	    + "} \r\n"
	    + "GROUP BY ?subject ?name  ?desc ?totalDesc ?region\r\n"
	    + "HAVING(?relevanceScore > 0)\r\n"
	    + "ORDER BY DESC(?relevanceScore)";
	    
	      System.out.println("pass ");
//	    String queryString="PREFIX untitled-ontology-5: <http://www.semanticweb.org/feven/ontologies/2023/4/untitled-ontology-5#>\r\n"
//	        + "\r\n"
//	        + "SELECT ?subject ?description WHERE {\r\n"
//	        + "  ?subject untitled-ontology-5:Description ?description .\r\n"
//	        + "}";
	      Query query = QueryFactory.create(queryString);
	      try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
	          ResultSet results = qexec.execSelect();
	          System.out.println(results.getRowNumber());
                  List<Destination> destinations = new ArrayList<>();
	          if (results != null) {
	              while (results.hasNext()) {
	                  QuerySolution soln = results.nextSolution();
	  	            
	    	          
	                    String subject = soln.getResource("subject").getURI();
	  	            String name = soln.getLiteral("name").getString();
	  	            String desc = soln.getLiteral("desc").getString();
	  	            String region = soln.getLiteral("region").getString();
	  	            String totalDesc = soln.getLiteral("totalDesc").getString();
//	  	            String imageAuthor = soln.getLiteral("region").getString();
	  	           // String distance = soln.getLiteral("distance").getString();
	  	            
                            Destination destination = new Destination();
                            destination.setSubject(subject);
                            
                            	  	        	  	           
                                  String newName = name.replace("\\", "");
                                  newName = newName.replace("\\", "");
                                  newName = newName.replaceAll("'", "");
                                  newName = newName.replaceAll("'", "");
//System.out.println(newName);
//                            String  x=name.replace("'", "");
                                   
                            destination.setName(newName);
                            destination.setDescription(desc);
                            destination.setRegion(region);
                            destination.setTotalDescription(totalDesc);
                            
                            destinations.add(destination);
                             System.out.println(destination.getName());
	  	           
	  	            //System.out.println("Subject: " + subject);
	  	            System.out.println("name: " + name);
	  	            System.out.println("desc: " + desc);
	  	            System.out.println("totalDesc: " + totalDesc);	  	
	  	            System.out.println("region: " + region); 	
	  	          //  System.out.println("distance: " + distance);
	  	      	
	  	            System.out.println(" "); 	
                            
//                            displayResults(destinations);
	  	
	              }
	          }
                  System.out.println(destinations.size());
                     if(destinations.isEmpty()){
                             
                     VBox newResultBox=new VBox();
                     
                            Text x=new Text("No Results");
                            newResultBox.getChildren().add(x);
                            
                     
                     
                     resultBox.getChildren().add(newResultBox);
                     }else{
                  try{
                   
                  for(int i=0;i<destinations.size();i++){
                      FXMLLoader fxmlLoader=new FXMLLoader();
                      fxmlLoader.setLocation(getClass().getResource("/UI/resultCard.fxml"));
                     VBox newResultBox=fxmlLoader.load();
                     
                             
                     resultCardController resultController=fxmlLoader.getController();
                     resultController.setData(destinations.get(i));  
                     
                     resultBox.getChildren().add(newResultBox);
//                     scrollPane.setClip(newResultBox);
                    
                     
                  }}catch(IOException e){
                      e.printStackTrace();
                  }}
               
	      }
	  }
    
    static void displayResults(List<Destination> results) {
    
    
    
    }
	
    @Override      
    public void initialize(URL url, ResourceBundle rb) {
       String[] alphabets = {"History", "   Events", "   Periods", "   TraditionalPractices", "Music", "   Genres",
        "   Instruments", "   Performances", "OralTraditions", "   folklore", "Personalities", "   Artist", "   Community_Leaders",
        "   Historians", "   Poets", "Religion", "   Rituals", "Archaeology", "   Artifacts", "Architecture", "   Buildings",
        "   Landscapes", "   Monuments", "Cuisine", "   Drinks", "   Foods"};

        ObservableList<String> alphabetList = FXCollections.observableArrayList(alphabets);
        comboBox.setItems(alphabetList);
        comboBox.setValue("");
        
        searchTerm.setText("");
            
    }       
    

}


