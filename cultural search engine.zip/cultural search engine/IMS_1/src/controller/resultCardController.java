
  
  package controller;


import java.io.IOException;
import java.net.URL;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.VBox;
import model.Destination;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.util.FileManager;
  
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
  
public class resultCardController implements Initializable {        

    @FXML
    private Text descfield;

    @FXML
    private Text namefield;

    @FXML
    private Button namefieldBtn;

    @FXML
    private Text regionfield;

    @FXML
    private AnchorPane singleResult;
    
    @FXML
    private VBox newBox;
    
   
    @FXML
    void namefieldBtn(ActionEvent event) {
        String subject=namefieldBtn.getId();
        System.out.println(subject);
        
                    try {
                // Load the new screen FXML file and its controller
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/UI/detail.fxml"));
                   ResultController controller = new ResultController(subject);
    loader.setController(controller);
    
                AnchorPane layout = loader.load();

                // Set the title of the new screen
//                controller.setTitle("New Screen");

                // Create a new scene with the layout and show it
                Scene newScene = new Scene(layout, 965.0, 746.0);
                Stage newStage = new Stage();
                newStage.setTitle("New Screen");
                newStage.setScene(newScene);
                newStage.show();
                                   
            } catch (IOException e) {
                e.printStackTrace();
            }
        
    }
    
   
    public void setData(Destination result){
        
                
        
        namefieldBtn.setText(result.getName());
        namefieldBtn.setId(result.getSubject());
        
        descfield.setText(result.getDescription());
        
        
        regionfield.setText(result.getRegion());
        
        namefieldBtn.setStyle("-fx-alignment: center-left; -fx-background-color:  white; ");
        namefieldBtn.setAlignment(Pos.CENTER_LEFT);
        
            namefieldBtn.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                namefieldBtn.setStyle("-fx-background-color:  white; -fx-text-fill: red;");
            }
        });
    }
//#7aaaea
    
  
    @Override      
    public void initialize(URL url, ResourceBundle rb) {

            
    }       
    

}


