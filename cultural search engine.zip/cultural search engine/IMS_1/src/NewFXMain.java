/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell
 */


///package t;


import java.util.ArrayList;
import java.util.List;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.util.FileManager;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TreeItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class NewFXMain extends Application {
    private double x=0;
    private double y=0;
    @Override
    public void start(Stage primaryStage) throws Exception{
        
            Parent  root=FXMLLoader.load(getClass().getResource("UI/MainFXML.fxml"));
            
            Scene scene = new Scene(root);
            
            root.setOnMousePressed((MouseEvent event) ->{
                x=event.getSceneX();
                y=event.getSceneY();             
            });
            
            root.setOnMouseDragged((MouseEvent event) ->{
                primaryStage.setX(event.getSceneX()-x);
                primaryStage.setY(event.getSceneY()-y);
                
                primaryStage.setOpacity(0.8);
            });
            
            root.setOnMouseReleased((MouseEvent event) ->{               
                primaryStage.setOpacity(1);
            });            
            
//            primaryStage.initStyle(StageStyle.TRANSPARENT);


 primaryStage.setScene(scene);
            primaryStage.show();
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
                 launch(args);
	}
	
	


}
//String queryString = "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n"
//+ "PREFIX untitled-ontology-5: <http://www.semanticweb.org/feven/ontologies/2023/4/untitled-ontology-5#>\n"
//+ "SELECT DISTINCT ?subject ?name ?desc ?totalDesc ?region ((count(?mid) + "
//+ "((CONTAINS(LCASE(?name), \"" + searchTerm.toLowerCase() + "\") * 4) + "
//+ "(CONTAINS(LCASE(?desc), \"" + searchTerm.toLowerCase() + "\") * 3) + "
//+ "(CONTAINS(LCASE(?region), \"" + searchTerm.toLowerCase() + "\") * 2) + "
//+ "(CONTAINS(LCASE(?totalDesc), \"" + searchTerm.toLowerCase() + "\")))) "
//+ "as ?relevanceScore) WHERE {\n"
//+ "  ?subject a/rdfs:subClassOf* untitled-ontology-5:" + classType + " .\n"
//+ "  ?subject untitled-ontology-5:Name ?name .\n"
//+ "  ?subject untitled-ontology-5:Description ?desc .\n"
//+ "  ?subject untitled-ontology-5:TotalDescription ?totalDesc .\n"
//+ "  ?subject untitled-ontology-5:Region ?region .\n"
//+ "  FILTER (\n"
//+ "      regex(?name, \"" + searchTerm + "\", \"i\") ||\n"
//+ "      regex(?desc, \"" + searchTerm + "\", \"i\") ||\n"
//+ "      regex(?region, \"" + searchTerm + "\", \"i\") ||\n"
//+ "      regex(?totalDesc, \"" + searchTerm + "\", \"i\")\n"
//+ "  ) .\n"
//+ "  {\n"
//+ "    untitled-ontology-5:" + classType + " rdfs:subClassOf* ?mid .\n"
//+ "  } UNION {\n"
//+ "    ?mid rdfs:subClassOf* untitled-ontology-5:" + classType + " .\n"
//+ "  }\n"
//+ "  ?subject a ?mid .\n"
//+ "} GROUP BY ?subject ?name ?desc ?totalDesc ?region ORDER BY DESC(?relevanceScore)";



//distance...
//String queryString = "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n"
//+ "PREFIX untitled-ontology-5: <http://www.semanticweb.org/feven/ontologies/2023/4/untitled-ontology-5#>\n"
//+ "SELECT DISTINCT ?subject ?name ?desc ?totalDesc ?region (count(?mid) as ?distance) WHERE {\n"
//+ "  ?subject a/rdfs:subClassOf* untitled-ontology-5:" + classType + " .\n"
//+ "  ?subject untitled-ontology-5:Name ?name .\n"
//+ "  ?subject untitled-ontology-5:Description ?desc .\n"
//+ "  ?subject untitled-ontology-5:TotalDescription ?totalDesc .\n"
//+ "  ?subject untitled-ontology-5:Region ?region .\n"
//+ "  FILTER (\n"
//+ "      regex(?name, \"" + searchTerm + "\", \"i\") ||\n"
//+ "      regex(?desc, \"" + searchTerm + "\", \"i\") ||\n"
//+ "      regex(?region, \"" + searchTerm + "\", \"i\") ||\n"
//+ "      regex(?totalDesc, \"" + searchTerm + "\", \"i\")\n"
//+ "  ) .\n"
//+ "  {\n"
//+ "    untitled-ontology-5:" + classType + " rdfs:subClassOf* ?mid .\n"
//+ "  } UNION {\n"
//+ "    ?mid rdfs:subClassOf* untitled-ontology-5:" + classType + " .\n"
//+ "  }\n"
//+ "  ?subject a ?mid .\n"
//+ "} GROUP BY ?subject ?name ?desc ?totalDesc ?region ORDER BY DESC(?distance)";

